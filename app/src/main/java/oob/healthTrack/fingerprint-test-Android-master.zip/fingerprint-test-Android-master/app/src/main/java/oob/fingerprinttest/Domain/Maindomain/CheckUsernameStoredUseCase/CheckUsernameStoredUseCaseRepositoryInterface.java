package oob.fingerprinttest.Domain.Maindomain.CheckUsernameStoredUseCase;

public interface CheckUsernameStoredUseCaseRepositoryInterface {
    boolean check();
}
