package oob.fingerprinttest;


public enum StepType {
    WALKING,
    JOGGING,
    RUNNING
}
