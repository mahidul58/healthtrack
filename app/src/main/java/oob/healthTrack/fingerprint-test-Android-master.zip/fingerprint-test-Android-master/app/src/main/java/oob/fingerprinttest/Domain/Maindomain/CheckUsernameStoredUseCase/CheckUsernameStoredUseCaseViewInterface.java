package oob.fingerprinttest.Domain.Maindomain.CheckUsernameStoredUseCase;

import android.content.Context;

public interface CheckUsernameStoredUseCaseViewInterface {
    Context getContext();
}
