package oob.fingerprinttest.ui.acceleration_sensor;

import androidx.lifecycle.ViewModel;

public class acceleration_SensorViewModel extends ViewModel {

}
